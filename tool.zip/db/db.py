# -*- coding: utf-8 -*-
"""db：mychat 会话持久化（sqlite3 标准库，四张表 sessions / messages /
agents / token_usage）。

库文件默认在 ~/.mychat/chat.db，可用环境变量 MYCHAT_DB 覆盖（自测用）。
重启后可续聊、可切换历史会话。

会话对外标识是唯一 uuid（列表/切换/恢复都用它）；内部 int 自增 id 只做
messages 的外键。updated 记录会话最后活跃时间；列表以最后一条消息为准
排序、取摘要。thinking 消息也入库（role='thinking'），由上层决定是否
进 API 历史。
"""

import os
import sqlite3
import uuid
from pathlib import Path

# 默认库文件：用户主目录（自测时用 MYCHAT_DB 指到临时文件，不污染真实数据）
DB_PATH = Path(os.environ.get("MYCHAT_DB", Path.home() / ".mychat" / "chat.db"))


def get_conn() -> sqlite3.Connection:
    """获取连接（父目录自动创建；row_factory 按列名取值）。"""
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db() -> None:
    """建表（幂等）+ 老库迁移（补 uuid/updated 列并回填）。"""
    with get_conn() as conn:
        conn.execute("PRAGMA foreign_keys = ON")
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS sessions(
            id      INTEGER PRIMARY KEY AUTOINCREMENT,
            uuid    TEXT    UNIQUE,
            title   TEXT    DEFAULT '',
            created TEXT    DEFAULT (datetime('now', 'localtime')),
            updated TEXT
        );
        CREATE TABLE IF NOT EXISTS messages(
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id INTEGER NOT NULL REFERENCES sessions(id),
            role       TEXT    NOT NULL,      -- 'user' / 'assistant' / 'thinking'
            content    TEXT    NOT NULL,
            created    TEXT    DEFAULT (datetime('now', 'localtime'))
        );
        """)
        # 老库迁移：缺列就补（SQLite 的 ADD COLUMN 不支持 UNIQUE，用索引代替）
        cols = {r["name"] for r in conn.execute("PRAGMA table_info(sessions)")}
        if "uuid" not in cols:
            conn.execute("ALTER TABLE sessions ADD COLUMN uuid TEXT")
        if "updated" not in cols:
            conn.execute("ALTER TABLE sessions ADD COLUMN updated TEXT")
        conn.execute(
            "CREATE UNIQUE INDEX IF NOT EXISTS idx_sessions_uuid ON sessions(uuid)")
        # 后台子 agent 登记表：spawn 时 INSERT 一行，收尾时 UPDATE 一次。
        # 写入频率极低（一个 agent 一生只有两次写），同步 sqlite3 毫无压力。
        # 子 agent 的对话流不进库（走 .agents/transcripts/<id>.jsonl 追加写，
        # 并发零竞争），表里只留"登记 + 最终报告"两个强一致快照
        conn.execute("""
        CREATE TABLE IF NOT EXISTS agents(
            id          TEXT PRIMARY KEY,   -- agent-3f2a1b（对外标识）
            parent_id   TEXT NOT NULL,      -- 挂靠的主会话 uuid（标记用，不做外键）
            spec_name   TEXT NOT NULL,      -- explore / verify / general
            status      TEXT NOT NULL,      -- running / done / failed / cancelled
            prompt      TEXT NOT NULL,      -- 当初的任务书（自包含那份）
            report      TEXT,               -- 最终报告
            created_at  TEXT DEFAULT (datetime('now', 'localtime')),
            finished_at TEXT
        );
        """)
        # token 用量表：一行 = 一次大模型调用（主循环每轮 / persona 摘要 /
        # 子 agent 的调用各一行）。四类 token 分列存——费率不同，混了算
        # 不了钱；对话级/会话级汇总全部查询时现算（单会话几百行，GROUP BY
        # 微秒级），不建汇总表
        conn.execute("""
        CREATE TABLE IF NOT EXISTS token_usage(
            id                  INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id          TEXT    NOT NULL,   -- 主会话 uuid；无上下文的调用记 'adhoc'
            dialog_id           INTEGER,            -- 所属对话 = 触发它的 user 消息 id（messages.id）
            agent_id            TEXT,               -- 子 agent id（agents.id）；主对话为 NULL
            model               TEXT    NOT NULL,
            input_tokens        INTEGER NOT NULL DEFAULT 0,
            output_tokens       INTEGER NOT NULL DEFAULT 0,
            cache_read_tokens   INTEGER NOT NULL DEFAULT 0,
            cache_write_tokens  INTEGER NOT NULL DEFAULT 0,
            created             TEXT    DEFAULT (datetime('now', 'localtime'))
        );
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_usage_session "
                     "ON token_usage(session_id)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_usage_dialog "
                     "ON token_usage(dialog_id)")
        # 回填：老会话补 uuid；updated 以最后一条消息时间为准（没消息用 created）
        for r in conn.execute(
                "SELECT id FROM sessions WHERE uuid IS NULL OR uuid = ''").fetchall():
            conn.execute("UPDATE sessions SET uuid = ? WHERE id = ?",
                         (str(uuid.uuid4()), r["id"]))
        conn.execute("""
            UPDATE sessions SET updated = COALESCE(
                (SELECT MAX(created) FROM messages m WHERE m.session_id = sessions.id),
                created)
            WHERE updated IS NULL
        """)


def new_session() -> str:
    """开新会话，返回唯一 uuid（对外会话标识）。"""
    with get_conn() as conn:
        uid = str(uuid.uuid4())
        conn.execute(
            "INSERT INTO sessions (uuid, updated) "
            "VALUES (?, datetime('now', 'localtime'))", (uid,))
        return uid


def _sid(conn: sqlite3.Connection, session_uuid: str) -> int | None:
    """uuid（或前缀解析前的精确值）→ 内部 int id，找不到返回 None。"""
    row = conn.execute(
        "SELECT id FROM sessions WHERE uuid = ?", (session_uuid,)).fetchone()
    return row["id"] if row else None


def resolve_session(ref: str) -> str | None:
    """定位会话：完整 uuid 或唯一前缀（如前 8 位），返回完整 uuid，找不到/前缀歧义返回 None。"""
    if not ref:
        return None
    with get_conn() as conn:
        row = conn.execute(
            "SELECT uuid FROM sessions WHERE uuid = ?", (ref,)).fetchone()
        if row:
            return row["uuid"]
        rows = conn.execute(
            "SELECT uuid FROM sessions WHERE uuid LIKE ?", (ref + "%",)).fetchall()
        return rows[0]["uuid"] if len(rows) == 1 else None


def set_title(session_uuid: str, title: str) -> None:
    """设置会话标题（取首条用户消息前 30 字）。"""
    with get_conn() as conn:
        conn.execute("UPDATE sessions SET title = ? WHERE uuid = ?",
                     (title, session_uuid))


def add_message(session_uuid: str, role: str, content: str) -> int:
    """追加一条消息，并把会话 updated 刷成现在。返回消息自增 id——
    user 消息的 id 兼作对话号（token_usage.dialog_id 引用它）。"""
    with get_conn() as conn:
        sid = _sid(conn, session_uuid)
        if sid is None:
            raise KeyError(f"会话不存在: {session_uuid}")
        cur = conn.execute(
            "INSERT INTO messages (session_id, role, content) VALUES (?, ?, ?)",
            (sid, role, content))
        conn.execute(
            "UPDATE sessions SET updated = datetime('now', 'localtime') "
            "WHERE id = ?", (sid,))
        return cur.lastrowid


def load_messages(session_uuid: str) -> list:
    """读会话全部消息，返回 [{"role": ..., "content": ...}]。"""
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT m.role, m.content FROM messages m "
            "JOIN sessions s ON m.session_id = s.id "
            "WHERE s.uuid = ? ORDER BY m.id",
            (session_uuid,)).fetchall()
    return [{"role": r["role"], "content": r["content"]} for r in rows]


def list_sessions(limit: int = 20) -> list:
    """会话列表（只含有消息的会话，按最后一条消息时间倒序）。

    每行以最后一次对话为准：last_time / last_role / last_content
    是该会话最后一条消息的时间/角色/内容，创建时间单独给 created。
    """
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT s.uuid, s.title, s.created, "
            "       (SELECT MAX(created) FROM messages m "
            "         WHERE m.session_id = s.id) AS last_time, "
            "       (SELECT role FROM messages m "
            "         WHERE m.session_id = s.id "
            "         ORDER BY m.id DESC LIMIT 1) AS last_role, "
            "       (SELECT content FROM messages m "
            "         WHERE m.session_id = s.id "
            "         ORDER BY m.id DESC LIMIT 1) AS last_content "
            "FROM sessions s "
            "WHERE EXISTS (SELECT 1 FROM messages m WHERE m.session_id = s.id) "
            "ORDER BY last_time DESC, s.id DESC LIMIT ?",
            (limit,)).fetchall()
    return [
        {"uuid": r["uuid"], "title": r["title"], "created": r["created"],
         "last_time": r["last_time"], "last_role": r["last_role"],
         "last_content": r["last_content"]}
        for r in rows
    ]


def session_exists(session_uuid: str) -> bool:
    return resolve_session(session_uuid) is not None


def latest_session_id() -> str | None:
    """重启续聊用的会话（uuid）：最近有消息的那个；没有消息则 None。"""
    with get_conn() as conn:
        row = conn.execute(
            "SELECT s.uuid FROM messages m "
            "JOIN sessions s ON m.session_id = s.id "
            "ORDER BY m.id DESC LIMIT 1").fetchone()
        return row["uuid"] if row else None


# ---- 后台子 agent 登记（agents 表）----

def register_agent(agent_id: str, parent_id: str, spec_name: str,
                   prompt: str) -> None:
    """spawn 时登记一行（status='running'）。agent_id 重复会撞主键报错，
    由调用方（supervisor）保证唯一。"""
    with get_conn() as conn:
        conn.execute(
            "INSERT INTO agents (id, parent_id, spec_name, status, prompt) "
            "VALUES (?, ?, ?, 'running', ?)",
            (agent_id, parent_id, spec_name, prompt))


def finish_agent(agent_id: str, status: str, report: str) -> None:
    """收尾一次 UPDATE（status/report/finished_at）。找不到登记时抛 KeyError。
    status 取 running 之外：done / failed / cancelled。"""
    with get_conn() as conn:
        cur = conn.execute(
            "UPDATE agents SET status = ?, report = ?, "
            "finished_at = datetime('now', 'localtime') WHERE id = ?",
            (status, report, agent_id))
        if cur.rowcount == 0:
            raise KeyError(f"agent 未登记: {agent_id}")


def list_agents(parent_id: str | None = None,
                status: str | None = None) -> list:
    """查子 agent 登记簿。可按主会话/状态过滤，创建时间倒序。
    TUI 任务面板和"重启后查表补报"都走这里。"""
    sql = "SELECT id, parent_id, spec_name, status, prompt, report, " \
          "created_at, finished_at FROM agents"
    cond, args = [], []
    if parent_id is not None:
        cond.append("parent_id = ?"); args.append(parent_id)
    if status is not None:
        cond.append("status = ?"); args.append(status)
    if cond:
        sql += " WHERE " + " AND ".join(cond)
    sql += " ORDER BY created_at DESC, rowid DESC"   # rowid 兜底同秒插入序
    with get_conn() as conn:
        rows = conn.execute(sql, args).fetchall()
    return [dict(r) for r in rows]


# ---- token 用量（token_usage 表：一行 = 一次模型调用）----

# 四类 token 的列名（汇总口径用；input 不含缓存，总数 = 四列相加）
USAGE_TOKEN_COLS = ("input_tokens", "output_tokens",
                    "cache_read_tokens", "cache_write_tokens")


def add_token_usage(session_id: str, model: str,
                    input_tokens: int, output_tokens: int,
                    cache_read_tokens: int, cache_write_tokens: int,
                    dialog_id: int | None = None,
                    agent_id: str | None = None) -> None:
    """记一次模型调用的 usage。归属三件套：会话 / 对话（user 消息 id）/
    子 agent（None = 主对话）。由 model 层在每次 API 响应后调用；
    落库失败由调用方兜住（统计不能影响对话），这里如实抛。"""
    with get_conn() as conn:
        conn.execute(
            "INSERT INTO token_usage (session_id, dialog_id, agent_id, model, "
            "input_tokens, output_tokens, cache_read_tokens, cache_write_tokens) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (session_id, dialog_id, agent_id, model,
             input_tokens, output_tokens, cache_read_tokens, cache_write_tokens))


def _usage_total(rows: list) -> dict:
    """对聚合行求合计（calls + 四类 token）。空列表给全零。"""
    keys = ("calls",) + USAGE_TOKEN_COLS
    return {k: sum(r[k] or 0 for r in rows) for k in keys}


def dialog_usage(dialog_id: int) -> dict:
    """单次对话的消耗（含主 agent 和子 agent 的全部调用）：
    {"by_model": [...], "total": {...}}，按模型分组 + 合计。"""
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT model, COUNT(*) AS calls, "
            "       SUM(input_tokens)      AS input_tokens, "
            "       SUM(output_tokens)     AS output_tokens, "
            "       SUM(cache_read_tokens) AS cache_read_tokens, "
            "       SUM(cache_write_tokens) AS cache_write_tokens "
            "FROM token_usage WHERE dialog_id = ? GROUP BY model",
            (dialog_id,)).fetchall()
    return {"by_model": [dict(r) for r in rows], "total": _usage_total(rows)}


def session_usage(session_uuid: str) -> dict:
    """会话总消耗：{"dialogs": [...], "total": {...}}——每次对话一行
    （带问题摘要，可直接对账哪次最烧）+ 会话合计。子 agent 的调用
    本就带着主会话的 session_id，自动计入；'adhoc' 行不混进来。"""
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT t.dialog_id AS dialog_id, "
            "       (SELECT substr(content, 1, 30) FROM messages m "
            "         WHERE m.id = t.dialog_id) AS question, "
            "       COUNT(*) AS calls, "
            "       SUM(t.input_tokens)       AS input_tokens, "
            "       SUM(t.output_tokens)      AS output_tokens, "
            "       SUM(t.cache_read_tokens)  AS cache_read_tokens, "
            "       SUM(t.cache_write_tokens) AS cache_write_tokens "
            "FROM token_usage t WHERE t.session_id = ? "
            "GROUP BY t.dialog_id ORDER BY t.dialog_id",
            (session_uuid,)).fetchall()
    return {"dialogs": [dict(r) for r in rows], "total": _usage_total(rows)}


if __name__ == "__main__":
    # 自测：建库、开会话（uuid）、读写消息、前缀定位、列表以最后一条为准
    import tempfile

    old = DB_PATH
    DB_PATH = Path(tempfile.mkdtemp()) / "test.db"

    init_db()
    s1 = new_session()
    assert isinstance(s1, str) and len(s1) == 36 and s1.count("-") == 4, \
        f"会话 id 应为标准 uuid: {s1}"
    set_title(s1, "第一条会话")
    add_message(s1, "user", "你好")
    add_message(s1, "thinking", "思考过程")
    add_message(s1, "assistant", "你好，我是 mychat")
    assert load_messages(s1) == [
        {"role": "user", "content": "你好"},
        {"role": "thinking", "content": "思考过程"},
        {"role": "assistant", "content": "你好，我是 mychat"},
    ], "消息（含 thinking）应原样读回"

    s2 = new_session()
    assert session_exists(s1) and not session_exists("no-such-session")
    assert resolve_session(s1[:8]) == s1, "短 uuid 前缀应能定位会话"
    assert resolve_session("") is None, "空引用应返回 None"
    assert latest_session_id() == s1, "最近有消息的会话是 s1"

    rows = list_sessions()
    uuids = [r["uuid"] for r in rows]
    assert s1 in uuids and s2 not in uuids, "空会话不应出现在列表里"
    r1 = next(r for r in rows if r["uuid"] == s1)
    assert r1["last_content"] == "你好，我是 mychat", "摘要应是最后一条消息"
    assert r1["last_role"] == "assistant" and r1["last_time"], "应有最后消息角色/时间"
    assert r1["created"], "应有创建时间"

    # ---- agents 表：登记 → 收尾 → 查表过滤 ----
    register_agent("agent-aaa111", s1, "explore", "调研权限链路")
    register_agent("agent-bbb222", s1, "verify", "跑 shell 自测")
    register_agent("agent-ccc333", s2, "general", "修 bug")
    assert [a["id"] for a in list_agents(parent_id=s1)] == \
        ["agent-bbb222", "agent-aaa111"], "按会话过滤 + 创建时间倒序"
    assert all(a["status"] == "running" for a in list_agents()), \
        "新登记的 status 应为 running"
    assert all(a["report"] is None for a in list_agents()), "report 初始为空"

    finish_agent("agent-aaa111", "done", "审批链路：三道闸…")
    rows = list_agents(status="done")
    assert len(rows) == 1 and rows[0]["id"] == "agent-aaa111"
    assert rows[0]["report"] == "审批链路：三道闸…"
    assert rows[0]["finished_at"], "收尾应落 finished_at"
    assert [a["id"] for a in list_agents(status="running")] == \
        ["agent-ccc333", "agent-bbb222"], "按状态过滤"

    try:
        finish_agent("agent-nope", "done", "x")
    except KeyError:
        print("未登记收尾     OK: 抛 KeyError")
    else:
        raise AssertionError("收尾未登记的 agent 应抛 KeyError")

    # id 重复：主键拦截（supervisor 依赖这个约束保证唯一）
    try:
        register_agent("agent-aaa111", s1, "explore", "重复登记")
    except sqlite3.IntegrityError:
        print("主键防重       OK")
    else:
        raise AssertionError("重复 id 应撞主键")

    # ---- token_usage：逐调用记账 → 对话/会话两级汇总 ----
    d1 = add_message(s1, "user", "第一个问题：看看权限模块")   # 返回 id 即对话号
    add_token_usage(s1, "glm-5.3", 100, 50, 0, 0, dialog_id=d1)
    add_token_usage(s1, "glm-5.3", 10, 5, 2000, 300, dialog_id=d1,
                    agent_id="agent-aaa111")   # 子 agent 的调用同归 d1
    add_token_usage(s1, "doubao-seed-code-1-6", 20, 8, 100, 0, dialog_id=d1)
    d2 = add_message(s1, "user", "第二个问题")
    add_token_usage(s1, "glm-5.3", 30, 10, 500, 0, dialog_id=d2)
    add_token_usage("adhoc", "glm-5.3", 1, 1, 0, 0)   # 无上下文调用

    du = dialog_usage(d1)
    assert du["total"]["calls"] == 3, "对话 1 应含主/子 agent 共 3 次调用"
    assert du["total"]["input_tokens"] == 130 and \
        du["total"]["cache_read_tokens"] == 2100, du["total"]
    assert {r["model"] for r in du["by_model"]} == \
        {"glm-5.3", "doubao-seed-code-1-6"}, "按模型分组"
    print("对话级汇总     OK:", du["total"])

    su = session_usage(s1)
    assert su["total"]["calls"] == 4, "会话合计 = 两次对话，不含 adhoc"
    assert [d["calls"] for d in su["dialogs"]] == [3, 1]
    assert su["dialogs"][0]["question"].startswith("第一个问题"), \
        "对话行应带问题摘要（join messages）"
    empty = session_usage(s2)
    assert empty["total"]["calls"] == 0 and empty["dialogs"] == [], \
        "空会话应给全零而非报错"
    print("会话级汇总     OK:", su["total"])

    print("db 自测全部通过（tempdb:", DB_PATH, "）")

    DB_PATH = old
